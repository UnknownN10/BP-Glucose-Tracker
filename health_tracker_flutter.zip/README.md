# Health Tracker (Flutter) — Scaffold

This project is a ready-to-build Flutter scaffold for a combined Blood Pressure + Glucose tracker with:
- Multiple profiles (with photos)
- Morning / Noon / Night time-slot entries
- Dark mode support
- PDF export (printing)
- SQLite (sqflite) local persistence

**Important:** This repository is a scaffold. You must build the APK on your machine or CI (instructions below).

## How to build APK locally

1. Install Flutter SDK: https://flutter.dev/docs/get-started/install
2. From this project root:
   ```bash
   flutter pub get
   flutter build apk --release
   ```
3. The release APK will be in:
   `build/app/outputs/flutter-apk/app-release.apk`

## Build on CI / cloud
You can use Codemagic, GitHub Actions, or Bitrise. If you want, I can generate a GitHub Actions workflow or Codemagic config.

## Notes
- Image picking uses `image_picker` — test on a real device or emulator with gallery access.
- PDF export uses `printing` and `share_plus`.
- Database uses `sqflite` with simple DAOs in `lib/db/`.
