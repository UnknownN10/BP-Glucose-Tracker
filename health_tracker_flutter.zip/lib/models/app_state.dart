import 'package:flutter/material.dart';
import 'package:health_tracker_flutter/db/db_helper.dart';
import 'package:health_tracker_flutter/models/profile.dart';

class AppState extends ChangeNotifier {
  ThemeMode themeMode = ThemeMode.system;
  List<Profile> profiles = [];
  Profile? activeProfile;

  Future<void> init() async {
    await DBHelper.instance.initDB();
    profiles = await DBHelper.instance.getProfiles();
    if (profiles.isEmpty) {
      final p = Profile(id: 'default', name: 'My Profile');
      await DBHelper.instance.insertProfile(p);
      profiles = await DBHelper.instance.getProfiles();
    }
    activeProfile = profiles.first;
    notifyListeners();
  }

  Future<void> refreshProfiles() async {
    profiles = await DBHelper.instance.getProfiles();
    if (activeProfile == null && profiles.isNotEmpty) activeProfile = profiles.first;
    notifyListeners();
  }

  void setActive(Profile p) {
    activeProfile = p;
    notifyListeners();
  }

  void toggleThemeCycle() {
    if (themeMode == ThemeMode.system) themeMode = ThemeMode.dark;
    else if (themeMode == ThemeMode.dark) themeMode = ThemeMode.light;
    else themeMode = ThemeMode.system;
    notifyListeners();
  }
}
