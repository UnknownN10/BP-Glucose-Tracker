class Profile {
  final String id;
  String name;
  String? photoUri;

  Profile({required this.id, required this.name, this.photoUri});

  Map<String, dynamic> toMap() => {'id': id, 'name': name, 'photoUri': photoUri};
  static Profile fromMap(Map<String, dynamic> m) => Profile(id: m['id'] as String, name: m['name'] as String, photoUri: m['photoUri'] as String?);
}
