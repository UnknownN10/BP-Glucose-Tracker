class BpEntry {
  final String id;
  final String profileId;
  final String date;
  final String timeSlot; // morning|noon|night
  final int systolic;
  final int diastolic;
  final int? pulse;
  final String? notes;

  BpEntry({required this.id, required this.profileId, required this.date, required this.timeSlot, required this.systolic, required this.diastolic, this.pulse, this.notes});

  Map<String,dynamic> toMap() => {
    'id': id, 'profileId': profileId, 'date': date, 'timeSlot': timeSlot,
    'systolic': systolic, 'diastolic': diastolic, 'pulse': pulse, 'notes': notes
  };
}
