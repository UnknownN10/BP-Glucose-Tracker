class GlucoseEntry {
  final String id;
  final String profileId;
  final String date;
  final String timeSlot;
  final int? fasting;
  final int? beforeMeal;
  final int? afterMeal;
  final int? randomVal;
  final String? notes;

  GlucoseEntry({required this.id, required this.profileId, required this.date, required this.timeSlot, this.fasting, this.beforeMeal, this.afterMeal, this.randomVal, this.notes});

  Map<String,dynamic> toMap() => {
    'id': id, 'profileId': profileId, 'date': date, 'timeSlot': timeSlot,
    'fasting': fasting, 'beforeMeal': beforeMeal, 'afterMeal': afterMeal, 'randomVal': randomVal, 'notes': notes
  };
}
