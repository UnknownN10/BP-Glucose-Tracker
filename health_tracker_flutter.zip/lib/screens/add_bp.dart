import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import 'package:provider/provider.dart';
import 'package:health_tracker_flutter/models/app_state.dart';
import 'package:health_tracker_flutter/db/db_helper.dart';

class AddBpScreen extends StatefulWidget {
  @override
  _AddBpScreenState createState() => _AddBpScreenState();
}

class _AddBpScreenState extends State<AddBpScreen> {
  final _systolic = TextEditingController();
  final _diastolic = TextEditingController();
  final _pulse = TextEditingController();
  String _slot = 'morning';

  @override
  Widget build(BuildContext context) {
    final app = Provider.of<AppState>(context);
    return Scaffold(
      appBar: AppBar(title: Text('Add BP')),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Column(children: [
          DropdownButton<String>(value: _slot, items: ['morning','noon','night'].map((s)=>DropdownMenuItem(value:s,child:Text(s))).toList(), onChanged: (v)=>setState(()=>_slot=v!)),
          TextField(controller: _systolic, keyboardType: TextInputType.number, decoration: InputDecoration(labelText:'Systolic')),
          TextField(controller: _diastolic, keyboardType: TextInputType.number, decoration: InputDecoration(labelText:'Diastolic')),
          TextField(controller: _pulse, keyboardType: TextInputType.number, decoration: InputDecoration(labelText:'Pulse (optional)')),
          SizedBox(height:12),
          ElevatedButton(onPressed: () async {
            if (app.activeProfile==null) return;
            final id = Uuid().v4();
            final now = DateTime.now();
            final db = await DBHelper.instance.database;
            await db.insert('bp', {
                'id': id,
                'profileId': app.activeProfile!.id,
                'date': now.toIso8601String(),
                'timeSlot': _slot,
                'systolic': int.tryParse(_systolic.text) ?? 0,
                'diastolic': int.tryParse(_diastolic.text) ?? 0,
                'pulse': int.tryParse(_pulse.text),
                'notes': ''
              });
            Navigator.pop(context);
          }, child: Text('Save'))
        ]),
      ),
    );
  }
}
