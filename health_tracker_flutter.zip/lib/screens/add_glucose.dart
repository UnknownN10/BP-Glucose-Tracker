import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import 'package:provider/provider.dart';
import 'package:health_tracker_flutter/models/app_state.dart';
import 'package:health_tracker_flutter/db/db_helper.dart';

class AddGlucoseScreen extends StatefulWidget {
  @override
  _AddGlucoseScreenState createState() => _AddGlucoseScreenState();
}

class _AddGlucoseScreenState extends State<AddGlucoseScreen> {
  final _fast = TextEditingController();
  final _before = TextEditingController();
  final _after = TextEditingController();
  final _random = TextEditingController();
  String _slot = 'morning';

  @override
  Widget build(BuildContext context) {
    final app = Provider.of<AppState>(context);
    return Scaffold(
      appBar: AppBar(title: Text('Add Glucose')),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Column(children: [
          DropdownButton<String>(value: _slot, items: ['morning','noon','night'].map((s)=>DropdownMenuItem(value:s,child:Text(s))).toList(), onChanged: (v)=>setState(()=>_slot=v!)),
          TextField(controller: _fast, keyboardType: TextInputType.number, decoration: InputDecoration(labelText:'Fasting (mg/dL)')),
          TextField(controller: _before, keyboardType: TextInputType.number, decoration: InputDecoration(labelText:'Before meal (mg/dL)')),
          TextField(controller: _after, keyboardType: TextInputType.number, decoration: InputDecoration(labelText:'After meal (mg/dL)')),
          TextField(controller: _random, keyboardType: TextInputType.number, decoration: InputDecoration(labelText:'Random (mg/dL)')),
          SizedBox(height:12),
          ElevatedButton(onPressed: () async {
            if (app.activeProfile==null) return;
            final id = Uuid().v4();
            final now = DateTime.now();
            final db = await DBHelper.instance.database;
            await db.insert('glucose', {
                'id': id,
                'profileId': app.activeProfile!.id,
                'date': now.toIso8601String(),
                'timeSlot': _slot,
                'fasting': int.tryParse(_fast.text),
                'beforeMeal': int.tryParse(_before.text),
                'afterMeal': int.tryParse(_after.text),
                'randomVal': int.tryParse(_random.text),
                'notes': ''
              });
            Navigator.pop(context);
          }, child: Text('Save'))
        ]),
      ),
    );
  }
}
