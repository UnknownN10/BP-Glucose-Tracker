import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:health_tracker_flutter/models/app_state.dart';
import 'package:health_tracker_flutter/screens/add_bp.dart';
import 'package:health_tracker_flutter/screens/add_glucose.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final state = Provider.of<AppState>(context);
    return Scaffold(
      appBar: AppBar(
        title: Text('Health Tracker'),
        actions: [
          IconButton(icon: Icon(Icons.person), onPressed: () => Navigator.pushNamed(context, '/profiles')),
          IconButton(icon: Icon(Icons.brightness_6), onPressed: () => state.toggleThemeCycle()),
        ],
      ),
      body: Center(
        child: Column(
          children: [
            SizedBox(height:20),
            Text('Active: ${state.activeProfile?.name ?? "None"}'),
            SizedBox(height:20),
            ElevatedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AddBpScreen())), child: Text('Add BP (Morning/Noon/Night)')),
            ElevatedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AddGlucoseScreen())), child: Text('Add Glucose')),
          ],
        ),
      ),
    );
  }
}
