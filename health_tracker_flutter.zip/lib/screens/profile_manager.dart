import 'package:flutter/material.dart';
import 'package:health_tracker_flutter/models/profile.dart';
import 'package:health_tracker_flutter/db/db_helper.dart';
import 'package:provider/provider.dart';
import 'package:health_tracker_flutter/models/app_state.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:uuid/uuid.dart';

class ProfileManagerScreen extends StatefulWidget {
  @override
  _ProfileManagerScreenState createState() => _ProfileManagerScreenState();
}

class _ProfileManagerScreenState extends State<ProfileManagerScreen> {
  List<Profile> profiles = [];
  final _ctrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    profiles = await DBHelper.instance.getProfiles();
    setState((){});
  }

  Future pickPhoto(Profile p) async {
    final ImagePicker picker = ImagePicker();
    final XFile? img = await picker.pickImage(source: ImageSource.gallery, imageQuality: 70);
    if (img == null) return;
    p.photoUri = img.path;
    await DBHelper.instance.insertProfile(p);
    await load();
  }

  Future addProfile() async {
    final id = Uuid().v4();
    final p = Profile(id: id, name: _ctrl.text.trim());
    await DBHelper.instance.insertProfile(p);
    _ctrl.clear();
    await load();
    final app = Provider.of<AppState>(context, listen:false);
    app.refreshProfiles();
  }

  @override
  Widget build(BuildContext context) {
    final app = Provider.of<AppState>(context);
    return Scaffold(
      appBar: AppBar(title: Text('Profiles')),
      body: Column(
        children: [
          Expanded(child: ListView.builder(itemCount: profiles.length, itemBuilder: (_,i){
            final p = profiles[i];
            return ListTile(
              leading: p.photoUri!=null ? CircleAvatar(backgroundImage: FileImage(File(p.photoUri!))) : CircleAvatar(child: Text(p.name[0])),
              title: Text(p.name),
              trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                IconButton(icon: Icon(Icons.photo), onPressed: () => pickPhoto(p)),
                IconButton(icon: Icon(Icons.delete), onPressed: () async {
                  await DBHelper.instance.deleteProfile(p.id);
                  await load();
                  app.refreshProfiles();
                })
              ]),
              onTap: (){
                app.setActive(p);
                Navigator.pop(context);
              },
            );
          })),
          Padding(
            padding: EdgeInsets.all(12),
            child: Row(children: [
              Expanded(child: TextField(controller: _ctrl, decoration: InputDecoration(hintText: 'New profile name'))),
              ElevatedButton(onPressed: addProfile, child: Text('Add'))
            ]),
          )
        ],
      ),
    );
  }
}
