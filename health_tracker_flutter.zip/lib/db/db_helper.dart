import 'dart:io';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:health_tracker_flutter/models/profile.dart';

class DBHelper {
  static final DBHelper instance = DBHelper._init();
  static Database? _db;
  DBHelper._init();

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _initDB('health.db');
    return _db!;
  }

  Future<Database> _initDB(String fileName) async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    final path = join(documentsDirectory.path, fileName);
    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    await db.execute(
      'CREATE TABLE profiles (id TEXT PRIMARY KEY, name TEXT, photoUri TEXT);'
    );
    await db.execute(
      'CREATE TABLE bp (id TEXT PRIMARY KEY, profileId TEXT, date TEXT, timeSlot TEXT, systolic INTEGER, diastolic INTEGER, pulse INTEGER, notes TEXT);'
    );
    await db.execute(
      'CREATE TABLE glucose (id TEXT PRIMARY KEY, profileId TEXT, date TEXT, timeSlot TEXT, fasting INTEGER, beforeMeal INTEGER, afterMeal INTEGER, randomVal INTEGER, notes TEXT);'
    );
  }

  Future<void> initDB() async {
    await database;
  }

  // Profiles CRUD
  Future<List<Profile>> getProfiles() async {
    final db = await database;
    final maps = await db.query('profiles');
    return maps.map((m) => Profile.fromMap(m)).toList();
  }

  Future<void> insertProfile(Profile p) async {
    final db = await database;
    await db.insert('profiles', p.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> deleteProfile(String id) async {
    final db = await database;
    await db.delete('profiles', where: 'id = ?', whereArgs: [id]);
    await db.delete('bp', where: 'profileId = ?', whereArgs: [id]);
    await db.delete('glucose', where: 'profileId = ?', whereArgs: [id]);
  }
}
