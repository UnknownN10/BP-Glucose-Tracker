import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:health_tracker_flutter/screens/home_screen.dart';
import 'package:health_tracker_flutter/screens/profile_manager.dart';
import 'package:health_tracker_flutter/models/app_state.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(ChangeNotifierProvider(
    create: (_) => AppState()..init(),
    child: HealthApp(),
  ));
}

class HealthApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final state = Provider.of<AppState>(context);
    return MaterialApp(
      title: 'Health Tracker',
      theme: ThemeData.light(),
      darkTheme: ThemeData.dark(),
      themeMode: state.themeMode,
      home: HomeScreen(),
      routes: {
        '/profiles': (_) => ProfileManagerScreen(),
      },
    );
  }
}
